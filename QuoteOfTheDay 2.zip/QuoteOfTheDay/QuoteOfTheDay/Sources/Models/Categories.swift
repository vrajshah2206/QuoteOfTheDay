//
//  Categories.swift
//  QuoteOfTheDay
//
//  Created by Savan Savani on 2023-06-04.
//

import Foundation

let categories = [
    "Wisdom",
    "Inspiration",
    "Humor",
    "Life",
    "Change",
    "Equality",
    "Success",
    "Fashion",
    "Dreams",
    "Courage",
    "Spirituality",
    "Love",
    "Leadership",
    "Imagination",
    "Freedom",
    "Literature",
    "Perseverance",
    "Optimism",
    "Self-Reliance",
    "Art",
    "Faith",
    "Nature",
    "Simplicity",
    "Creativity",
    "Science",
    "Education",
    "Curiosity",
    "Kindness",
    "Philosophy",
    "Empowerment",
    "Knowledge",
    "Innovation",
    "Relationships",
    "Beauty"
]

